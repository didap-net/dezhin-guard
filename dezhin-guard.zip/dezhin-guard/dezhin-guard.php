<?php
/**
 * Plugin Name: Dezhin Guard
 * Plugin URI: https://didap.net/
 * Description: قفل پیشخوان دژین: امنیت ورود مدیران به داشبورد با قابلیت قفل ورود دوم، مسدودسازی با محدودیت تلاش و لاگ ورود. 
 * Version: 3.5.0
 * Author: Didap
 * Author URI: https://didap.net/
 * Text Domain: dezhin_guard
 * Tested up to: 6.7
 */

if (!defined('ABSPATH')) {
    exit;
}

/*
  Design goals implemented:
  - All checks limited to wp-admin (except admin-ajax/admin-post which are excluded).
  - Password stored hashed (password_hash). Compare with password_verify.
  - Cookie set with Secure + HttpOnly. If session duration = 0 -> session cookie (expire=0).
  - Log attempts only for users whose role is in configured locked roles.
  - Limit attempts & IP block only applied for locked-role users.
  - Malicious agents blocking runs only in admin and not for AJAX/admin-post.
  - Lock form uses nonce and has brute-force protection.
  - Cron cleanup for logs works and honors retention option.
*/

/* ------------------------- Helpers ------------------------- */

function sal_get_real_ip() {
    foreach (array('HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR') as $h) {
        if (!empty($_SERVER[$h])) {
            $ip = $_SERVER[$h];
            if ($h === 'HTTP_X_FORWARDED_FOR') {
                // may contain comma list
                $ip = explode(',', $ip)[0];
            }
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return '0.0.0.0';
}

function sal_allowed_locked_roles() {
    $roles = get_option('dezhin_guard_roles', array());
    if (!is_array($roles)) $roles = array(); // safety
    return $roles;
}

function sal_current_user_has_locked_role() {
    if (!is_user_logged_in()) return false;
    $user = wp_get_current_user();
    $locked = sal_allowed_locked_roles();
    if (empty($locked)) return false;
    return (bool) array_intersect($user->roles, $locked);
}

function sal_set_auth_cookie_for_hash($hash) {
    // cookie name derived from hash (stored hash)
    $cookie_name = 'sal_authenticated_' . md5($hash);
    $duration_hours = intval(get_option('dezhin_guard_session_duration', 24));
    if ($duration_hours > 0) {
        $expire = time() + ($duration_hours * 3600);
    } else {
        // if 0 -> session cookie (expire = 0)
        $expire = 0;
    }
    $secure = is_ssl();
    // Try to use PHP 7.3+ options array if available for SameSite support
    if (PHP_VERSION_ID >= 70300) {
        setcookie($cookie_name, '1', array(
            'expires' => $expire,
            'path' => '/',
            'domain' => '', // default
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax'
        ));
    } else {
        // fallback
        setcookie($cookie_name, '1', $expire, '/', '', $secure, true);
    }
}

function sal_clear_auth_cookie_for_hash($hash) {
    $cookie_name = 'sal_authenticated_' . md5($hash);
    if (PHP_VERSION_ID >= 70300) {
        setcookie($cookie_name, '', array(
            'expires' => time() - 3600,
            'path' => '/',
            'domain' => '',
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax'
        ));
    } else {
        setcookie($cookie_name, '', time() - 3600, '/', '', is_ssl(), true);
    }
}

/* ------------------------- Activation: create table & schedule ------------------------- */

function sal_activate_plugin() {
    global $wpdb;
    $table = $wpdb->prefix . 'admin_login_attempts';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$table} (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(100) NOT NULL,
        username VARCHAR(255) NOT NULL DEFAULT '',
        status VARCHAR(50) NOT NULL,
        attempt_time DATETIME NOT NULL,
        user_agent VARCHAR(255) NULL,
        referer VARCHAR(255) NULL
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);

    if (!wp_next_scheduled('sal_daily_event')) {
        wp_schedule_event(time(), 'daily', 'sal_daily_event');
    }
}
register_activation_hook(__FILE__, 'sal_activate_plugin');

function sal_deactivate_plugin() {
    // remove cron
    $timestamp = wp_next_scheduled('sal_daily_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'sal_daily_event');
    }
}
register_deactivation_hook(__FILE__, 'sal_deactivate_plugin');

/* ------------------------- Admin menu & settings page ------------------------- */

add_action('admin_menu', function() {
    add_options_page(
        'قفل پیشخوان دژین',
        'قفل پیشخوان دژین',
        'manage_options',
        'dezhin_guard',
        'sal_settings_page'
    );
});

function sal_settings_page() {
    if (!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');

    // defaults
    $defaults = array(
        'max_attempts' => 3,
        'block_time' => 15, // minutes
        'whitelist_ips' => '',
        'malicious_agents' => 'sqlmap,dirbuster,nmap,burpsuite',
        'roles' => array(),
        'session_duration' => 24,
        'log_retention' => 7,
    );

    // handle post
    if (isset($_POST['sal_save']) && check_admin_referer('sal_settings_nonce')) {
        $old_hash = get_option('dezhin_guard_dashboard_password', '');
        $new_password = isset($_POST['dashboard_password']) ? sanitize_text_field($_POST['dashboard_password']) : '';
        if (!empty($new_password)) {
            $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
            update_option('dezhin_guard_dashboard_password', $new_hash);
            // clear old cookie if hash changed
            if (!empty($old_hash) && $old_hash !== $new_hash) {
                sal_clear_auth_cookie_for_hash($old_hash);
            }
        }
        update_option('dezhin_guard_max_attempts', intval($_POST['max_attempts'] ?? $defaults['max_attempts']));
        update_option('dezhin_guard_block_time', intval($_POST['block_time'] ?? $defaults['block_time']));
        update_option('dezhin_guard_whitelist_ips', sanitize_text_field($_POST['whitelist_ips'] ?? ''));
        update_option('dezhin_guard_malicious_agents', sanitize_text_field($_POST['malicious_agents'] ?? $defaults['malicious_agents']));
        $roles = array_map('sanitize_text_field', $_POST['roles'] ?? array());
        update_option('dezhin_guard_roles', $roles);
        update_option('dezhin_guard_session_duration', intval($_POST['session_duration'] ?? $defaults['session_duration']));
        update_option('dezhin_guard_log_retention', intval($_POST['log_retention'] ?? $defaults['log_retention']));

        echo '<div class="notice notice-success"><p>تنظیمات ذخیره شدند.</p></div>';
    }

    // read settings
    $settings = array(
        'max_attempts' => get_option('dezhin_guard_max_attempts', $defaults['max_attempts']),
        'block_time' => get_option('dezhin_guard_block_time', $defaults['block_time']),
        'whitelist_ips' => get_option('dezhin_guard_whitelist_ips', $defaults['whitelist_ips']),
        'malicious_agents' => get_option('dezhin_guard_malicious_agents', $defaults['malicious_agents']),
        'roles' => get_option('dezhin_guard_roles', $defaults['roles']),
        'session_duration' => get_option('dezhin_guard_session_duration', $defaults['session_duration']),
        'log_retention' => get_option('dezhin_guard_log_retention', $defaults['log_retention']),
    );

    global $wpdb;
    $table = $wpdb->prefix . 'admin_login_attempts';
    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} ORDER BY attempt_time DESC LIMIT %d", 100));

    // render form (password field is empty for security)
    ?>
    <div class="wrap">
        <h1>تنظیمات قفل پیشخوان دژین</h1>
        <form method="post">
            <?php wp_nonce_field('sal_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th>رمز عبور قفل داشبورد</th>
                    <td>
                        <input type="password" name="dashboard_password" value="">
                        <p class="description">اگر می‌خواهید رمز جدید بگذارید، اینجا وارد کنید.</p>
                    </td>
                </tr>
                <tr>
                    <th>تعداد دفعات تلاش ناموفق</th>
                    <td><input type="number" name="max_attempts" value="<?php echo esc_attr($settings['max_attempts']); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>مدت زمان مسدودسازی (دقیقه)</th>
                    <td><input type="number" name="block_time" value="<?php echo esc_attr($settings['block_time']); ?>" min="1"></td>
                </tr>
                <tr>
                    <th>مدت زمان سشن (ساعت)</th>
                    <td>
                        <input type="number" name="session_duration" value="<?php echo esc_attr($settings['session_duration']); ?>" min="0">
                        <p class="description">اگر 0 وارد شود، سشن بصورت session cookie خواهد بود (نامحدود تا بسته شدن مرورگر).</p>
                    </td>
                </tr>
                <tr>
                    <th>لیست IP‌های وایت‌لیست</th>
                    <td>
                        <textarea name="whitelist_ips"><?php echo esc_textarea($settings['whitelist_ips']); ?></textarea>
                        <p class="description">آی‌پی‌ها را با کاما جدا کنید.</p>
                    </td>
                </tr>
                <tr>
                    <th>لیست User-Agentهای مهاجم</th>
                    <td>
                        <textarea name="malicious_agents"><?php echo esc_textarea($settings['malicious_agents']); ?></textarea>
                        <p class="description">کلماتی که در User-Agent می‌خواهید بلاک شوند را با کاما جدا کنید (مثلاً sqlmap,nmap).</p>
                    </td>
                </tr>
                <tr>
                    <th>نقش‌های تحت قفل</th>
                    <td>
                        <?php
                        $all_roles = wp_roles()->roles;
                        foreach ($all_roles as $role_key => $role_details) {
                            $checked = in_array($role_key, $settings['roles']) ? 'checked' : '';
                            echo '<label style="display:block;margin-bottom:4px;"><input type="checkbox" name="roles[]" value="'.esc_attr($role_key).'" '.$checked.'> '.esc_html($role_details['name']).'</label>';
                        }
                        ?>
                        <p class="description">برای هر نقشی که تیک بخورد لاگ‌ها و قفل داشبورد اعمال می‌شود.</p>
                    </td>
                </tr>
                <tr>
                    <th>نگهداری لاگ‌ها (روز)</th>
                    <td><input type="number" name="log_retention" value="<?php echo esc_attr($settings['log_retention']); ?>" min="1"></td>
                </tr>
            </table>
            <?php submit_button('ذخیره تنظیمات', 'primary', 'sal_save'); ?>
        </form>

        <h2>آخرین لاگ‌ها (حداکثر 100)</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>IP</th><th>یوزرنیم</th><th>وضعیت</th><th>زمان</th><th>User-Agent</th><th>Referer</th></tr></thead>
            <tbody>
            <?php if ($logs): foreach ($logs as $log): ?>
                <tr>
                    <td><?php echo esc_html($log->ip); ?></td>
                    <td><?php echo esc_html($log->username); ?></td>
                    <td><?php echo esc_html($log->status); ?></td>
                    <td><?php echo esc_html($log->attempt_time); ?></td>
                    <td><?php echo esc_html($log->user_agent); ?></td>
                    <td><?php echo esc_html($log->referer); ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="6">لاگی وجود ندارد.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

/* ------------------------- Malicious agents blocking (ADMIN only) ------------------------- */

function sal_block_malicious_requests_admin() {
    // Only run in admin context and not during AJAX/admin-post
    if (!is_admin()) return;
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    // also skip cron
    if (defined('DOING_CRON') && DOING_CRON) return;

    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (empty($ua)) return;

    $agents = get_option('dezhin_guard_malicious_agents', '');
    $agents_arr = array_filter(array_map('trim', explode(',', $agents)));
    if (empty($agents_arr)) return;

    foreach ($agents_arr as $a) {
        if ($a === '') continue;
        if (stripos($ua, $a) !== false) {
            status_header(403);
            wp_die('دسترسی مسدود شد (malicious user-agent)');
        }
    }
}
add_action('admin_init', 'sal_block_malicious_requests_admin', 5);

/* ------------------------- Session handling (ADMIN only, non-AJAX) ------------------------- */

function sal_secure_session_start_admin() {
    if (!is_admin()) return;
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (defined('DOING_CRON') && DOING_CRON) return;

    if (!session_id()) {
        ini_set('session.save_path', sys_get_temp_dir());
        @session_start();
        if (!isset($_SESSION['sal_ip'])) {
            $_SESSION['sal_ip'] = sal_get_real_ip();
            $_SESSION['sal_ua'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
        }
        session_write_close(); // don't keep session open
    }
}
add_action('init', 'sal_secure_session_start_admin', 1);

function sal_check_session_integrity_admin() {
    if (!is_admin()) return;
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (defined('DOING_CRON') && DOING_CRON) return;

    if (!session_id()) return;

    // reopen session briefly to check
    @session_start();
    $ip = $_SESSION['sal_ip'] ?? null;
    $ua = $_SESSION['sal_ua'] ?? null;
    @session_write_close();

    if (($ip && $ip !== sal_get_real_ip()) || ($ua && $ua !== ($_SERVER['HTTP_USER_AGENT'] ?? ''))) {
        // possible session hijack - destroy and redirect to login
        @session_start();
        session_destroy();
        wp_redirect(wp_login_url());
        exit;
    }
}
add_action('init', 'sal_check_session_integrity_admin', 2);

/* ------------------------- Logging helpers (only for locked roles) ------------------------- */

function sal_should_log_for_user($user) {
    if (!$user) return false;
    $locked = sal_allowed_locked_roles();
    if (empty($locked)) return false;
    return (bool) array_intersect($user->roles, $locked);
}

function sal_insert_log($username, $status) {
    global $wpdb;
    // try to find user object
    $user = get_user_by('login', $username);
    if (!$user) return; // we only log attempts for known users (and only if they are in locked roles)
    if (!sal_should_log_for_user($user)) return;

    $table = $wpdb->prefix . 'admin_login_attempts';
    $wpdb->insert($table, array(
        'ip' => sal_get_real_ip(),
        'username' => $username,
        'status' => $status,
        'attempt_time' => current_time('mysql'),
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'referer' => $_SERVER['HTTP_REFERER'] ?? ''
    ), array('%s','%s','%s','%s','%s','%s'));
}

/* ------------------------- Limit attempts & blocking (only for locked-role users) ------------------------- */

function sal_is_ip_whitelisted($ip = null) {
    $ip = $ip ?? sal_get_real_ip();
    $wl = get_option('dezhin_guard_whitelist_ips', '');
    $arr = array_filter(array_map('trim', explode(',', $wl)));
    return in_array($ip, $arr);
}

// check & increment failed attempts for a given username+ip
function sal_increment_failed_attempts($username) {
    $ip = sal_get_real_ip();
    if (sal_is_ip_whitelisted($ip)) return;

    $key = 'sal_failed_' . md5($username . '|' . $ip);
    $failed = (int) get_transient($key);
    $failed++;
    $block_minutes = max(1, intval(get_option('dezhin_guard_block_time', 15)));
    $ttl = $block_minutes * MINUTE_IN_SECONDS;
    set_transient($key, $failed, $ttl);

    $max = max(1, intval(get_option('dezhin_guard_max_attempts', 3)));
    if ($failed >= $max) {
        // set block flag
        $block_key = 'sal_blocked_ip_' . md5($ip);
        set_transient($block_key, 1, $ttl);
    }
    return $failed;
}

function sal_is_ip_blocked($ip = null) {
    $ip = $ip ?? sal_get_real_ip();
    $block_key = 'sal_blocked_ip_' . md5($ip);
    return (bool) get_transient($block_key);
}

/* ------------------------- WP hooks: login failed & login success ------------------------- */

// wp_login_failed handler: username attempt may not correspond to a user. We'll only process if user exists and role is in locked roles.
add_action('wp_login_failed', function($username) {
    // get user by login
    $user = get_user_by('login', $username);
    if (!$user) return;

    if (!sal_should_log_for_user($user)) return;

    // increment failed attempts for username+ip
    $failed = sal_increment_failed_attempts($username);

    // log failed attempt (insert directly)
    sal_insert_log($username, 'failed');
}, 10, 1);

// wp_login: successful WP auth. After login, we still need to check if user's role is in locked roles and then maybe set cookie via lock form flow.
add_action('wp_login', function($user_login, $user) {
    // Only log if user's role is in locked set
    if (sal_should_log_for_user($user)) {
        sal_insert_log($user_login, 'success');
    }
}, 10, 2);

/* ------------------------- Dashboard lock: show form and validate (ADMIN only, non-AJAX) ------------------------- */

function sal_dashboard_lock_handler() {
    // Only in admin (wp-admin) and not admin-ajax/admin-post
    if (!is_admin()) return;
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (defined('DOING_CRON') && DOING_CRON) return;

    if (!is_user_logged_in()) return; // normal WP login required first

    // check if current user's role is in locked set
    $user = wp_get_current_user();
    if (!$user || !sal_should_log_for_user($user)) return;

    // check whitelist IP
    if (sal_is_ip_whitelisted()) return;

    $stored_hash = get_option('dezhin_guard_dashboard_password', '');
    if (empty($stored_hash)) return; // no dashboard password set

    $cookie_name = 'sal_authenticated_' . md5($stored_hash);
    if (isset($_COOKIE[$cookie_name])) {
        // user already passed dashboard lock
        return;
    }

    // If form submitted - process
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sal_dashboard_lock_nonce'])) {
        if (!wp_verify_nonce($_POST['sal_dashboard_lock_nonce'], 'sal_dashboard_lock_action')) {
            wp_die('درخواست نامعتبر (nonce).');
        }

        $username = $user->user_login;
        // check blocked IP
        if (sal_is_ip_blocked()) {
            wp_die('Too many failed attempts. Please try later.');
        }

        $entered = isset($_POST['dashboard_lock_password']) ? sanitize_text_field($_POST['dashboard_lock_password']) : '';

        // verify password
        if (password_verify($entered, $stored_hash)) {
            // success - set cookie and log success
            sal_set_auth_cookie_for_hash($stored_hash);
            sal_insert_log($username, 'success'); // log success for locked users
            // redirect to same page to avoid form re-post
            wp_safe_redirect(remove_query_arg('_sal_lock'), 302);
            exit;
        } else {
            // failed - increment attempts & log
            sal_increment_failed_attempts($username);
            sal_insert_log($username, 'failed');
            // show message and fall through to show form again
            $error = 'رمز عبور نامعتبر است.';
        }
    }

    // show form (block rendering of admin until correct)
    // Use wp_die to present form; include nonce
    $html  = '<div style="max-width:480px;margin:60px auto;padding:20px;border:1px solid #ddd;background:#fff;border-radius:6px;text-align:center;">';
    $html .= '<h2>دسترسی به مدیریت</h2>';
    $html .= '<p>برای دسترسی به داشبورد، رمز قفل را وارد کنید.</p>';
    if (!empty($error)) {
        $html .= '<p style="color:#c00;font-weight:bold;">' . esc_html($error) . '</p>';
    }
    $html .= '<form method="post">';
    $html .= wp_nonce_field('sal_dashboard_lock_action', 'sal_dashboard_lock_nonce', true, false);
    $html .= '<input type="password" name="dashboard_lock_password" required style="width:100%;padding:8px;margin-bottom:10px;">';
    $html .= '<br><input type="submit" value="تایید" class="button button-primary">';
    $html .= '</form>';
    $html .= '</div>';

    wp_die($html, 403, array('response' => 403));
}
add_action('admin_init', 'sal_dashboard_lock_handler', 5);

/* ------------------------- Prevent redirecting AJAX/admin-post and keep front intact ------------------------- */

function sal_redirect_non_logged_admin() {
    // This was previously too aggressive. We only redirect when:
    // - in admin area (is_admin()), not doing AJAX/admin-post
    // - and the user is not logged in
    if (!is_admin()) return;
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    if (defined('DOING_CRON') && DOING_CRON) return;

    if (!is_user_logged_in()) {
        // allow access to wp-login.php itself
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        if (strpos($script, 'wp-login.php') !== false) return;
        // otherwise redirect to login
        wp_safe_redirect(wp_login_url());
        exit;
    }
}
add_action('admin_init', 'sal_redirect_non_logged_admin', 1);

/* ------------------------- Cron cleanup of logs ------------------------- */

add_action('sal_daily_event', function() {
    global $wpdb;
    $table = $wpdb->prefix . 'admin_login_attempts';
    $days = intval(get_option('dezhin_guard_log_retention', 7));
    if ($days <= 0) $days = 7;
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$table} WHERE attempt_time < DATE_SUB(NOW(), INTERVAL %d DAY)",
        $days
    ));
});

/* ------------------------- Utility: reset cookie if password changed externally ------------------------- */

add_action('update_option_dezhin_guard_dashboard_password', function($old_value, $new_value) {
    // clear cookie for old hash
    if (!empty($old_value) && $old_value !== $new_value) {
        sal_clear_auth_cookie_for_hash($old_value);
    }
}, 10, 2);

/* ------------------------- Misc: expose debug/status in admin footer (opt-in) ------------------------- */

// optional small debug output if ?sal_debug=1 and current user can manage_options
add_action('admin_notices', function() {
    if (!current_user_can('manage_options')) return;
    if (isset($_GET['sal_debug']) && $_GET['sal_debug'] == '1') {
        $locked = sal_allowed_locked_roles();
        echo '<div class="notice"><p><strong>SAL debug:</strong> locked roles = '.esc_html(implode(',', $locked)).'</p></div>';
    }
});

/* ------------------------- End plugin ------------------------- */



// =========================
// بروزرسان خودکار پلاگین
// =========================
require_once plugin_dir_path(__FILE__) . 'updater.php';

