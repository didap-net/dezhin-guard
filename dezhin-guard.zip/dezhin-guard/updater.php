<?php

// ========================
// بروزرسان خودکار پلاگین
// =========================

add_filter('pre_set_site_transient_update_plugins', 'sal_check_for_plugin_update');
add_filter('plugins_api', 'sal_plugin_info', 10, 3);

function sal_check_for_plugin_update($transient) {
    if (empty($transient->checked)) return $transient;

    $plugin_slug = 'dezhin-guard/dezhin-guard.php';
    $remote = wp_remote_get('https://cdn.jsdelivr.net/gh/didap-net/dezhin-guard@latest/update.json', array('timeout' => 10));

    if (!is_wp_error($remote) && wp_remote_retrieve_response_code($remote) == 200) {
        $remote = json_decode(wp_remote_retrieve_body($remote));

        if ($remote && isset($transient->checked[$plugin_slug]) && version_compare($transient->checked[$plugin_slug], $remote->version, '<')) {
            $obj = new stdClass();
            $obj->slug = $plugin_slug;
            $obj->new_version = $remote->version;
            $obj->package = $remote->download_url;
            $transient->response[$plugin_slug] = $obj;
        }
    }

    return $transient;
}

function sal_plugin_info($res, $action, $args) {
    if ($action !== 'plugin_information') return $res;

    $plugin_slug = plugin_basename(__FILE__);
    if ($args->slug !== $plugin_slug) return $res;

    $remote = wp_remote_get('https://cdn.jsdelivr.net/gh/didap-net/dezhin-guard@latest/update.json', array('timeout' => 10));
    if (!is_wp_error($remote) && wp_remote_retrieve_response_code($remote) == 200) {
        $remote = json_decode(wp_remote_retrieve_body($remote));
        $res = new stdClass();
        $res->name = 'قفل پیشخوان دژین';
        $res->slug = $plugin_slug;
        $res->version = $remote->version;
        $res->author = 'دیداپ';
        $res->download_link = $remote->download_url;
    }
    return $res;
}
